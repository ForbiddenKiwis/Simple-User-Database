import java.awt.*;
//Jerwinson-Flores Cunanan
public class Main {
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            new ContactManagerApp().setVisible(true);
        });
    }
}